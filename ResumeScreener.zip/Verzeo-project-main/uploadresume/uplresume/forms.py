from django import forms
from .models import Resume

GENDER_CHOICES = [
 ('Male', 'Male'),
 ('Female', 'Female')
]

JOB_CITY_CHOICE = [
 ('Delhi', 'Delhi'),
 ('Pune', 'Pune'),
 ('Ranchi', 'Ranchi'),
 ('Mumbai', 'Mumbai'),
 ('Dhanbad', 'Dhanbad'),
 ('Banglore', 'Banglore')
]

class ResumeForm(forms.ModelForm):
 class Meta:
  model = Resume
  fields = ['name','mobile', 'email','my_file']
  labels = {'name':'Full Name','mobile':'Mobile No.','email':'Email ID','my_file':'Document'}
  widgets = {
       'name':forms.TextInput(attrs={'class':'form-control'}),
       'mobile':forms.NumberInput(attrs={'class':'form-control'}),
       'email':forms.EmailInput(attrs={'class':'form-control'}),
      }